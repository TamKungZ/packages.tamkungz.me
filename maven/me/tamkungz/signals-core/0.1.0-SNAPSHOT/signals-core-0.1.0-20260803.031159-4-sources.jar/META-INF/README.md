# SignalsLib

A tiny Java signal/event library with optional Bukkit/Spigot integration, backed by
[GEB](https://central.sonatype.com/artifact/foo.zaaarf.geb/core).

- Minimum JDK: 17
- Bukkit/Spigot API baseline: 1.16.5
- Group: `me.tamkungz`
- Author: TamKungZ_ <dev@tamkungz.me>
- Website: https://dev.tamkungz.me

## Modules

- `signals-core` — pure Java, no Minecraft dependency
- `signals-bukkit` — Bukkit/Spigot bridge

## Core API

```java
SignalBus bus = SignalBus.create();
Signal<String> signal = bus.signal(String.class);

Connection connection = signal.connect(message -> {
    System.out.println("Got: " + message);
});

signal.fire("hello");
connection.disconnect();
```

Signals can be filtered, mapped, named, and grouped for cleanup:

```java
ConnectionGroup cleanup = ConnectionGroup.create();

Signal<String> chat = bus.signal(String.class, "chat");

chat.connectIf(cleanup, message -> message.startsWith("!"), message -> {
    System.out.println("Command-ish message: " + message);
});

Signal<Integer> lengths = chat.map(Integer.class, String::length);

lengths.filter(length -> length > 12)
    .connect(cleanup, length -> System.out.println("Long message: " + length));

cleanup.disconnect();
```

You can still use GEB directly through the same bus. This keeps GEB useful for
custom `IEvent` events and `@Listen` listeners while SignalsLib handles the
Minecraft-friendly facade:

```java
bus.registerListener(myGebListener);
bus.post(myGebEvent);
```

If your plugin defines its own GEB `@Listen` methods, enable the GEB annotation
processor in that plugin so its event dispatchers are generated.

## Bukkit example

```java
BukkitSignals signals = BukkitSignals.create(plugin);

signals.playerJoin().connect(event -> {
    event.getPlayer().sendMessage("Hello from Signal!");
});
```

Use the fluent Bukkit API when you need event priority or cancellation behavior:

```java
signals.playerInteract()
    .high()
    .ignoreCancelled()
    .connectIf(
        event -> event.getPlayer().hasPermission("signals.debug"),
        event -> event.getPlayer().sendMessage("debug interact")
    );
```

Every Bukkit event class is still available:

```java
signals.on(PlayerJoinEvent.class).connect(event -> {
    event.getPlayer().sendMessage("Hello from Signal!");
});
```

Or as a one-liner:

```java
BukkitSignals.from(plugin, PlayerJoinEvent.class)
    .connect(event -> event.getPlayer().sendMessage("Hello from Signal!"));
```

If the bundled jar is installed as a server plugin, other plugins can depend on
it and use the shared bus:

```yaml
depend: [SignalsLib]
```

```java
BukkitSignals signals = BukkitSignals.shared();

signals.playerJoin()
    .connect(event -> event.getPlayer().sendMessage("Hello from shared signals!"));
```

For listener cleanup, keep a group in your plugin and disconnect it on disable:

```java
public final class MyPlugin extends JavaPlugin {
    private final ConnectionGroup connections = ConnectionGroup.create();

    @Override
    public void onEnable() {
        BukkitSignals signals = BukkitSignals.shared();

        signals.blockBreak()
            .ignoreCancelled()
            .connect(connections, event -> {
                event.getPlayer().sendMessage("Block: " + event.getBlock().getType());
            });
    }

    @Override
    public void onDisable() {
        connections.disconnect();
    }
}
```

## GEB Direct Use

GEB is bundled without relocation, so plugin developers can use
`foo.zaaarf.geb.*` directly from the same jar.

```java
public final class EconomyListener implements IListener {
    @Listen(priority = 10)
    public void onCoinChange(CoinChangeEvent event) {
        // generated dispatcher, fast runtime call
    }
}

Connection connection = BukkitSignals.sharedBus().listen(new EconomyListener());
```

Custom GEB events should implement `IEvent` or `IEventCancelable`, and plugins
that define their own `@Listen` methods should enable the GEB annotation
processor at compile time:

```gradle
dependencies {
    compileOnly files("plugins/signals-bukkit-0.1.0-SNAPSHOT-all.jar")
    annotationProcessor "foo.zaaarf.geb:processor:0.4.5"
}
```

Sub-buses from GEB 0.5.0 are exposed too:

```java
SignalBus shared = BukkitSignals.sharedBus();
SignalBus local = SignalBus.create();

Connection bridge = shared.subBus(local.geb(), 1);
```

## Build

```bash
./gradlew build
```

```bash
./gradlew build -PspigotApiVersion=26.2-R0.1-SNAPSHOT
```

```bash
./gradlew publishAllPublicationsToLocalBuildRepository
```

Artifacts will be written to each module's `build/libs/` directory.

For Bukkit/Spigot plugin distribution, use the bundled jar:

```text
signals-bukkit/build/libs/signals-bukkit-0.1.0-SNAPSHOT-all.jar
```

Upload only that `-all.jar` to the server's `plugins/` directory. The bundled jar
includes `signals-core`, GEB, and `plugin.yml`. It does not relocate
`foo.zaaarf.geb`, so plugin developers can use the GEB API directly from the same
jar if they want.

## Credits

This project bundles and builds on GEB - Generative Event Bus.

- Project: https://zaaarf.foo/projects/geb/
- Source: https://github.com/zaaarf/geb
- Developer ID: `zaaarf`
- Developer email: `me@zaaarf.foo`
- License: MIT
