package me.tamkungz.signals;

import foo.zaaarf.geb.api.IEvent;

import java.util.Objects;

public final class SignalEvent<T> implements IEvent {
    private final SignalKey<T> key;
    private final T value;

    public SignalEvent(Class<T> eventType, T value) {
        this(SignalKey.of(eventType), value);
    }

    public SignalEvent(SignalKey<T> key, T value) {
        this.key = Objects.requireNonNull(key, "key");
        this.value = key.cast(value);
    }

    public SignalKey<T> key() {
        return key;
    }

    public Class<T> eventType() {
        return key.eventType();
    }

    public T value() {
        return value;
    }
}
