package me.tamkungz.signals;

import java.util.Arrays;
import java.util.Objects;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;

public final class ConnectionGroup implements Connection {
    private final CopyOnWriteArrayList<Connection> connections = new CopyOnWriteArrayList<>();
    private final AtomicBoolean connected = new AtomicBoolean(true);

    public static ConnectionGroup create() {
        return new ConnectionGroup();
    }

    public static ConnectionGroup of(Connection... connections) {
        ConnectionGroup group = create();
        Arrays.stream(connections).forEach(group::add);
        return group;
    }

    public <T extends Connection> T add(T connection) {
        Objects.requireNonNull(connection, "connection");
        if (isConnected()) {
            connections.add(connection);
        } else {
            connection.disconnect();
        }
        return connection;
    }

    public int size() {
        return connections.size();
    }

    @Override
    public void disconnect() {
        if (!connected.compareAndSet(true, false)) {
            return;
        }

        for (Connection connection : connections) {
            connection.disconnect();
        }
        connections.clear();
    }

    @Override
    public boolean isConnected() {
        return connected.get();
    }
}
