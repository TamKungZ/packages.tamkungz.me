package me.tamkungz.signals;

import foo.zaaarf.geb.api.IListener;
import foo.zaaarf.geb.api.annotations.Listen;

import java.util.List;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;

final class SignalRouter implements IListener {
    private final ConcurrentMap<SignalKey<?>, CopyOnWriteArrayList<Subscription<?>>> listeners = new ConcurrentHashMap<>();

    <T> Connection connect(Class<T> eventType, Consumer<T> listener) {
        return connect(SignalKey.of(eventType), listener);
    }

    <T> Connection connect(SignalKey<T> key, Consumer<T> listener) {
        Objects.requireNonNull(key, "key");
        Objects.requireNonNull(listener, "listener");

        Subscription<T> subscription = new Subscription<>(key, listener);
        listeners.computeIfAbsent(key, ignored -> new CopyOnWriteArrayList<>()).add(subscription);
        return subscription;
    }

    <T> Connection once(Class<T> eventType, Consumer<T> listener) {
        return once(SignalKey.of(eventType), listener);
    }

    <T> Connection once(SignalKey<T> key, Consumer<T> listener) {
        Connection[] holder = new Connection[] {Connection.disconnected()};
        holder[0] = connect(key, value -> {
            holder[0].disconnect();
            listener.accept(value);
        });
        return holder[0];
    }

    int listenerCount(Class<?> eventType) {
        return listenerCount(SignalKey.of(eventType));
    }

    int listenerCount(SignalKey<?> key) {
        List<Subscription<?>> subscriptions = listeners.get(key);
        return subscriptions == null ? 0 : subscriptions.size();
    }

    void clear(Class<?> eventType) {
        clear(SignalKey.of(eventType));
    }

    void clear(SignalKey<?> key) {
        List<Subscription<?>> subscriptions = listeners.remove(key);
        if (subscriptions == null) {
            return;
        }

        for (Subscription<?> subscription : subscriptions) {
            subscription.disconnect();
        }
    }

    void clear() {
        for (SignalKey<?> key : listeners.keySet()) {
            clear(key);
        }
        listeners.clear();
    }

    @Listen
    public void onSignal(SignalEvent<?> event) {
        List<Subscription<?>> subscriptions = listeners.get(event.key());
        if (subscriptions == null) {
            return;
        }

        for (Subscription<?> subscription : subscriptions) {
            subscription.accept(event.value());
        }
    }

    private final class Subscription<T> implements Connection {
        private final SignalKey<T> key;
        private final Consumer<T> listener;
        private final AtomicBoolean connected = new AtomicBoolean(true);

        private Subscription(SignalKey<T> key, Consumer<T> listener) {
            this.key = key;
            this.listener = listener;
        }

        @Override
        public void disconnect() {
            if (!connected.compareAndSet(true, false)) {
                return;
            }

            List<Subscription<?>> subscriptions = listeners.get(key);
            if (subscriptions != null) {
                subscriptions.remove(this);
                if (subscriptions.isEmpty()) {
                    listeners.remove(key, subscriptions);
                }
            }
        }

        @Override
        public boolean isConnected() {
            return connected.get();
        }

        private void accept(Object value) {
            if (isConnected()) {
                listener.accept(key.cast(value));
            }
        }
    }
}
