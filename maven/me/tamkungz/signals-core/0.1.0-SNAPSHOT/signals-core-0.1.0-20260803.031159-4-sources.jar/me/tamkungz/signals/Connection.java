package me.tamkungz.signals;

public interface Connection {
    static Connection all(Connection... connections) {
        return ConnectionGroup.of(connections);
    }

    static Connection disconnected() {
        return new Connection() {
            @Override
            public void disconnect() {
            }

            @Override
            public boolean isConnected() {
                return false;
            }
        };
    }

    void disconnect();

    boolean isConnected();

    default void close() {
        disconnect();
    }
}
