package me.tamkungz.signals;

import foo.zaaarf.geb.GEB;
import foo.zaaarf.geb.api.IBus;
import foo.zaaarf.geb.api.IEvent;
import foo.zaaarf.geb.api.IListener;

import java.util.Objects;
import java.util.function.Consumer;

/**
 * Minecraft-friendly facade over GEB.
 */
public final class SignalBus {
    private final IBus geb;
    private final SignalRouter router;

    public SignalBus() {
        this(new GEB());
    }

    public SignalBus(IBus geb) {
        this.geb = Objects.requireNonNull(geb, "geb");
        this.router = new SignalRouter();
        this.geb.registerListener(router);
    }

    public static SignalBus create() {
        return new SignalBus();
    }

    public IBus geb() {
        return geb;
    }

    public <T> Signal<T> signal(Class<T> eventType) {
        return signal(SignalKey.of(eventType));
    }

    public <T> Signal<T> signal(Class<T> eventType, String name) {
        return signal(SignalKey.named(eventType, name));
    }

    public <T> Signal<T> signal(SignalKey<T> key) {
        return new Signal<>(this, key);
    }

    <T> Signal<T> derivedSignal(Class<T> eventType) {
        return signal(SignalKey.unique(eventType));
    }

    public <T> Connection connect(Class<T> eventType, Consumer<T> listener) {
        return connect(SignalKey.of(eventType), listener);
    }

    public <T> Connection connect(SignalKey<T> key, Consumer<T> listener) {
        return router.connect(key, listener);
    }

    public <T> Connection connect(ConnectionGroup group, Class<T> eventType, Consumer<T> listener) {
        return group.add(connect(eventType, listener));
    }

    public <T> Connection once(Class<T> eventType, Consumer<T> listener) {
        return once(SignalKey.of(eventType), listener);
    }

    public <T> Connection once(SignalKey<T> key, Consumer<T> listener) {
        return router.once(key, listener);
    }

    public <T> Connection once(ConnectionGroup group, Class<T> eventType, Consumer<T> listener) {
        return group.add(once(eventType, listener));
    }

    public <T> void fire(Class<T> eventType, T value) {
        fire(SignalKey.of(eventType), value);
    }

    public <T> void fire(SignalKey<T> key, T value) {
        post(new SignalEvent<>(key, value));
    }

    public boolean post(IEvent event) {
        return geb.handleEvent(Objects.requireNonNull(event, "event"));
    }

    public Connection listen(IListener listener) {
        registerListener(listener);
        return new Connection() {
            @Override
            public void disconnect() {
                unregisterListener(listener);
            }

            @Override
            public boolean isConnected() {
                return isRegistered(listener);
            }
        };
    }

    public Connection listen(ConnectionGroup group, IListener listener) {
        return group.add(listen(listener));
    }

    public void registerListener(IListener listener) {
        geb.registerListener(Objects.requireNonNull(listener, "listener"));
    }

    public void unregisterListener(IListener listener) {
        geb.unregisterListener(Objects.requireNonNull(listener, "listener"));
    }

    public boolean isRegistered(IListener listener) {
        return geb.isRegistered(Objects.requireNonNull(listener, "listener"));
    }

    public Connection subBus(IBus subBus, int priority) {
        registerSubBus(subBus, priority);
        return new Connection() {
            @Override
            public void disconnect() {
                unregisterSubBus(subBus);
            }

            @Override
            public boolean isConnected() {
                return isRegistered(subBus);
            }
        };
    }

    public Connection subBus(ConnectionGroup group, IBus subBus, int priority) {
        return group.add(subBus(subBus, priority));
    }

    public void registerSubBus(IBus subBus, int priority) {
        geb.registerSubBus(Objects.requireNonNull(subBus, "subBus"), priority);
    }

    public void unregisterSubBus(IBus subBus) {
        geb.unregisterSubBus(Objects.requireNonNull(subBus, "subBus"));
    }

    public boolean isRegistered(IBus subBus) {
        return geb.isRegistered(Objects.requireNonNull(subBus, "subBus"));
    }

    public int listenerCount(Class<?> eventType) {
        return listenerCount(SignalKey.of(eventType));
    }

    public int listenerCount(SignalKey<?> key) {
        return router.listenerCount(key);
    }

    public void clear(Class<?> eventType) {
        clear(SignalKey.of(eventType));
    }

    public void clear(SignalKey<?> key) {
        router.clear(key);
    }

    public void clear() {
        router.clear();
    }
}
