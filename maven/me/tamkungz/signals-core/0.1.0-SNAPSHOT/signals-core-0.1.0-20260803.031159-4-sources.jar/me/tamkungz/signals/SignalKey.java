package me.tamkungz.signals;

import java.util.Objects;
import java.util.concurrent.atomic.AtomicLong;

public final class SignalKey<T> {
    private static final AtomicLong NEXT_ID = new AtomicLong();

    private final Class<T> eventType;
    private final String name;

    private SignalKey(Class<T> eventType, String name) {
        this.eventType = Objects.requireNonNull(eventType, "eventType");
        this.name = Objects.requireNonNull(name, "name");
    }

    public static <T> SignalKey<T> of(Class<T> eventType) {
        return named(eventType, "default");
    }

    public static <T> SignalKey<T> named(Class<T> eventType, String name) {
        return new SignalKey<>(eventType, name);
    }

    static <T> SignalKey<T> unique(Class<T> eventType) {
        return named(eventType, "derived-" + NEXT_ID.incrementAndGet());
    }

    public Class<T> eventType() {
        return eventType;
    }

    public String name() {
        return name;
    }

    T cast(Object value) {
        return eventType.cast(value);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof SignalKey)) {
            return false;
        }
        SignalKey<?> key = (SignalKey<?>) other;
        return eventType.equals(key.eventType) && name.equals(key.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(eventType, name);
    }

    @Override
    public String toString() {
        return eventType.getName() + "#" + name;
    }
}
