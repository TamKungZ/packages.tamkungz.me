package me.tamkungz.signals.bukkit;

import me.tamkungz.signals.Connection;
import me.tamkungz.signals.ConnectionGroup;
import me.tamkungz.signals.Signal;
import org.bukkit.event.Event;
import org.bukkit.event.EventPriority;

import java.util.function.Consumer;
import java.util.function.Predicate;

public final class BukkitEventSignal<T extends Event> {
    private final BukkitSignals signals;
    private final Class<T> eventType;
    private EventPriority priority = EventPriority.NORMAL;
    private boolean ignoreCancelled;

    BukkitEventSignal(BukkitSignals signals, Class<T> eventType) {
        this.signals = signals;
        this.eventType = eventType;
    }

    public BukkitEventSignal<T> priority(EventPriority priority) {
        this.priority = priority;
        return this;
    }

    public BukkitEventSignal<T> lowest() {
        return priority(EventPriority.LOWEST);
    }

    public BukkitEventSignal<T> low() {
        return priority(EventPriority.LOW);
    }

    public BukkitEventSignal<T> normal() {
        return priority(EventPriority.NORMAL);
    }

    public BukkitEventSignal<T> high() {
        return priority(EventPriority.HIGH);
    }

    public BukkitEventSignal<T> highest() {
        return priority(EventPriority.HIGHEST);
    }

    public BukkitEventSignal<T> monitor() {
        return priority(EventPriority.MONITOR);
    }

    public BukkitEventSignal<T> ignoreCancelled() {
        this.ignoreCancelled = true;
        return this;
    }

    public BukkitEventSignal<T> includeCancelled() {
        this.ignoreCancelled = false;
        return this;
    }

    public Signal<T> signal() {
        return signals.event(eventType, priority, ignoreCancelled);
    }

    public Connection connect(Consumer<T> listener) {
        return signal().connect(listener);
    }

    public Connection connect(ConnectionGroup group, Consumer<T> listener) {
        return signal().connect(group, listener);
    }

    public Connection connectIf(Predicate<T> predicate, Consumer<T> listener) {
        return signal().connectIf(predicate, listener);
    }

    public Connection connectIf(ConnectionGroup group, Predicate<T> predicate, Consumer<T> listener) {
        return signal().connectIf(group, predicate, listener);
    }

    public Connection once(Consumer<T> listener) {
        return signal().once(listener);
    }

    public Connection once(ConnectionGroup group, Consumer<T> listener) {
        return signal().once(group, listener);
    }
}
