package me.tamkungz.signals.bukkit;

import me.tamkungz.signals.Signal;
import me.tamkungz.signals.SignalBus;
import org.bukkit.Bukkit;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.Event;
import org.bukkit.event.EventPriority;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerKickEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.plugin.EventExecutor;
import org.bukkit.plugin.Plugin;

import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Small bridge from Bukkit events to GEB-backed signals.
 */
public final class BukkitSignals {
    private final Plugin plugin;
    private final SignalBus signals;
    private final Map<EventKey, Signal<? extends Event>> eventSignals = new ConcurrentHashMap<>();

    private BukkitSignals(Plugin plugin, SignalBus signals) {
        this.plugin = Objects.requireNonNull(plugin, "plugin");
        this.signals = Objects.requireNonNull(signals, "signals");
    }

    public static BukkitSignals create(Plugin plugin) {
        return new BukkitSignals(plugin, SignalBus.create());
    }

    public static BukkitSignals create(Plugin plugin, SignalBus signals) {
        return new BukkitSignals(plugin, signals);
    }

    public static BukkitSignals shared() {
        return SignalsPlugin.getInstance().signals();
    }

    public static SignalBus sharedBus() {
        return SignalsPlugin.getInstance().bus();
    }

    public SignalBus bus() {
        return signals;
    }

    public <T extends Event> BukkitEventSignal<T> on(Class<T> eventType) {
        return new BukkitEventSignal<>(this, eventType);
    }

    public <T extends Event> Signal<T> event(Class<T> eventType) {
        return event(eventType, EventPriority.NORMAL, false);
    }

    public <T extends Event> Signal<T> event(
            Class<T> eventType,
            EventPriority priority,
            boolean ignoreCancelled
    ) {
        EventKey key = new EventKey(eventType, priority, ignoreCancelled);
        @SuppressWarnings("unchecked")
        Signal<T> signal = (Signal<T>) eventSignals.computeIfAbsent(key, ignored -> registerEventSignal(
                eventType,
                priority,
                ignoreCancelled
        ));
        return signal;
    }

    public static <T extends Event> Signal<T> from(
            Plugin plugin,
            Class<T> eventType,
            EventPriority priority,
            boolean ignoreCancelled
    ) {
        return create(plugin).event(eventType, priority, ignoreCancelled);
    }

    public static <T extends Event> Signal<T> from(Plugin plugin, Class<T> eventType) {
        return from(plugin, eventType, EventPriority.NORMAL, false);
    }

    public BukkitEventSignal<PlayerJoinEvent> playerJoin() {
        return on(PlayerJoinEvent.class);
    }

    public BukkitEventSignal<PlayerQuitEvent> playerQuit() {
        return on(PlayerQuitEvent.class);
    }

    public BukkitEventSignal<PlayerKickEvent> playerKick() {
        return on(PlayerKickEvent.class);
    }

    public BukkitEventSignal<PlayerMoveEvent> playerMove() {
        return on(PlayerMoveEvent.class);
    }

    public BukkitEventSignal<PlayerTeleportEvent> playerTeleport() {
        return on(PlayerTeleportEvent.class);
    }

    public BukkitEventSignal<PlayerInteractEvent> playerInteract() {
        return on(PlayerInteractEvent.class);
    }

    public BukkitEventSignal<PlayerDeathEvent> playerDeath() {
        return on(PlayerDeathEvent.class);
    }

    public BukkitEventSignal<PlayerRespawnEvent> playerRespawn() {
        return on(PlayerRespawnEvent.class);
    }

    public BukkitEventSignal<PlayerCommandPreprocessEvent> playerCommand() {
        return on(PlayerCommandPreprocessEvent.class);
    }

    public BukkitEventSignal<BlockBreakEvent> blockBreak() {
        return on(BlockBreakEvent.class);
    }

    public BukkitEventSignal<BlockPlaceEvent> blockPlace() {
        return on(BlockPlaceEvent.class);
    }

    public BukkitEventSignal<EntityDamageEvent> entityDamage() {
        return on(EntityDamageEvent.class);
    }

    public BukkitEventSignal<EntityDeathEvent> entityDeath() {
        return on(EntityDeathEvent.class);
    }

    public BukkitEventSignal<InventoryClickEvent> inventoryClick() {
        return on(InventoryClickEvent.class);
    }

    public BukkitEventSignal<InventoryCloseEvent> inventoryClose() {
        return on(InventoryCloseEvent.class);
    }

    private <T extends Event> Signal<T> registerEventSignal(
            Class<T> eventType,
            EventPriority priority,
            boolean ignoreCancelled
    ) {
        Signal<T> signal = signals.signal(eventType);
        Listener listener = new Listener() {};
        EventExecutor executor = (ignored, event) -> {
            if (eventType.isInstance(event)) {
                signal.fire(eventType.cast(event));
            }
        };

        Bukkit.getPluginManager().registerEvent(
                eventType,
                listener,
                priority,
                executor,
                plugin,
                ignoreCancelled
        );

        return signal;
    }

    private static final class EventKey {
        private final Class<? extends Event> eventType;
        private final EventPriority priority;
        private final boolean ignoreCancelled;

        private EventKey(Class<? extends Event> eventType, EventPriority priority, boolean ignoreCancelled) {
            this.eventType = eventType;
            this.priority = priority;
            this.ignoreCancelled = ignoreCancelled;
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof EventKey)) {
                return false;
            }
            EventKey key = (EventKey) other;
            return ignoreCancelled == key.ignoreCancelled
                    && eventType.equals(key.eventType)
                    && priority == key.priority;
        }

        @Override
        public int hashCode() {
            return Objects.hash(eventType, priority, ignoreCancelled);
        }
    }
}
