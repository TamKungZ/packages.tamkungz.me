package me.tamkungz.signals.bukkit;

import me.tamkungz.signals.Connection;
import me.tamkungz.signals.ConnectionGroup;
import me.tamkungz.signals.SignalBus;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * Bukkit plugin entrypoint for servers that want to load SignalsLib as a shared library.
 */
public final class SignalsPlugin extends JavaPlugin {
    private BukkitSignals signals;
    private ConnectionGroup connections;

    @Override
    public void onLoad() {
        connections = ConnectionGroup.create();
        signals = BukkitSignals.create(this);
    }

    @Override
    public void onDisable() {
        if (connections != null) {
            connections.disconnect();
        }
        if (signals != null) {
            signals.bus().clear();
        }
    }

    public static SignalsPlugin getInstance() {
        return getPlugin(SignalsPlugin.class);
    }

    public BukkitSignals signals() {
        return signals;
    }

    public SignalBus bus() {
        return signals.bus();
    }

    public ConnectionGroup connections() {
        return connections;
    }

    public <T extends Connection> T track(T connection) {
        return connections.add(connection);
    }
}
